import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-furnitures',
  templateUrl: './furnitures.component.html',
  styleUrls: ['./furnitures.component.css']
})
export class FurnituresComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
