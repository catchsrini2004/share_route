import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-garments',
  templateUrl: './garments.component.html',
  styleUrls: ['./garments.component.css']
})
export class GarmentsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
