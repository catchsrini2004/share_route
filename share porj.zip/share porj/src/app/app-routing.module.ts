import { componentFactoryName } from '@angular/compiler';
import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { ElectronicsComponent } from './electronics/electronics.component';
import { FurnituresComponent } from './furnitures/furnitures.component';
import { GarmentsComponent } from './garments/garments.component';
import { LoginComponent } from './login/login.component';
import { LogoutComponent } from './logout/logout.component';
import { PagenotfoundComponent } from './pagenotfound/pagenotfound.component';
import { ProductsComponent } from './products/products.component';

const routes: Routes = [
  
  {path: '', redirectTo:'login', pathMatch: 'full'},
{path: 'login', component: LoginComponent},
{path: 'logout', component: LogoutComponent},
{path: 'product', component: ProductsComponent , children: [

  {path: 'fur', component: FurnituresComponent},
{path: 'ele', component: ElectronicsComponent},
{path: 'clo', component: GarmentsComponent} 
]},
{path: '**', component: PagenotfoundComponent},

];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
